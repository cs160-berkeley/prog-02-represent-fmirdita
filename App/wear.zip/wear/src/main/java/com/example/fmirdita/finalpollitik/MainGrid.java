package com.example.fmirdita.finalpollitik;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.hardware.TriggerEvent;
import android.hardware.TriggerEventListener;
import android.net.Uri;
import android.os.Bundle;
import android.support.wearable.view.CardFragment;
import android.support.wearable.view.DotsPageIndicator;
import android.support.wearable.view.FragmentGridPagerAdapter;
import android.support.wearable.view.GridPagerAdapter;
import android.support.wearable.view.GridViewPager;
import android.support.wearable.view.WatchViewStub;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.google.android.gms.common.api.GoogleApiClient;

import com.twitter.sdk.android.Twitter;
import com.twitter.sdk.android.core.TwitterAuthConfig;
import io.fabric.sdk.android.Fabric;
import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.List;

public class MainGrid extends Activity implements SensorEventListener {

    // Note: Your consumer key and secret should be obfuscated in your source code before shipping.
    private static final String TWITTER_KEY = "fq40LgB7PEThLKmXzJakpQPrn";
    private static final String TWITTER_SECRET = "cz93kAp6Pq4m52NoGuf2fAlth4Smwu9ACiDry4VQgsNB4I5n6V";
    String key = "AIzaSyD5kq_y5VNC_6FY0yuCT10CJfWYJ8FzFXE";

    final static String DATA = "DATA";
    private static Context mContext;
    private static Context appContext;
    Boolean shakeOccured = false;

    private static SensorManager mSensorManager;
    private static Sensor mSensor;
    private float[] mLastValues = {0,0,0};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TwitterAuthConfig authConfig = new TwitterAuthConfig(TWITTER_KEY, TWITTER_SECRET);
        Fabric.with(this, new Twitter(authConfig));
        setContentView(R.layout.activity_main_grid);

        mSensorManager = (SensorManager)getSystemService(SENSOR_SERVICE);
        mSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        mContext = getBaseContext();
        appContext = getApplicationContext();


        Intent intent = getIntent();
        Bundle extras = intent.getExtras();

        if (extras == null) {
            setContentView(R.layout.start_view);

        } else {
            makeGrid(extras.getString(DATA));
        }
    }

    private void makeGrid(String stringData) {

        final DotsPageIndicator mPageIndicator;
        final GridViewPager mViewPager;

        // Get UI references
        mPageIndicator = (DotsPageIndicator) findViewById(R.id.page_indicator);
        mViewPager = (GridViewPager) findViewById(R.id.pager);

        // Assigns an adapter to provide the content for this pager
        mViewPager.setAdapter(new GridPagerAdapter(getFragmentManager(), stringData));
        mPageIndicator.setPager(mViewPager);
    }


    private static final class GridPagerAdapter extends FragmentGridPagerAdapter {

        String[] mData;
        String location;

        private GridPagerAdapter(FragmentManager fm, String stringData) {
            super(fm);

            String[] splitInfo = stringData.split("Split");
            String repData = splitInfo[0];
            String results = splitInfo[1];
            stringData = repData + "+" + splitInfo[1];
            mData = stringData.split("\\+");
        }

        @Override
        public Fragment getFragment(int row, int column) {

            String[] fields = mData[row].split("\\*");

            for (String field : fields) {
                Log.e("FIELDS", "fields: " + field);}

            if (fields[1].equals("Voting Results")) {
                VoteCard voteCard = new VoteCard();
                voteCard.setDistrict("Voting Results of " + fields[0]);
                voteCard.setVoteResults(fields[2]);
                return voteCard;
            } else {

                String name = fields[0];
                String title;
                if (fields[1].equals("Rep")) {
                    title = "Representative";
                } else {
                    title = "Senator";
                }
                String party = fields[2];

                RepCard repCard = new RepCard();
                repCard.setTitle(title);
                repCard.setName(name);
                repCard.setParty(party);


                final String repData = mData[row];

                Log.e("I", "Setting service to click " + name);

                repCard.setCardClickListener(repData, mContext);
                return repCard;
            }
        }

        @Override
        public int getRowCount() {
            return mData.length;
        }

        @Override
        public int getColumnCount(int row) {
            return 1;
        }
    }

    public void startMainLocation(View v) {
        Intent intent = new Intent(mContext, WatchToPhoneService.class);
        intent.putExtra("DATA", "start");
        startService(intent);
    }

    protected void onResume() {
        mSensorManager.registerListener(this,
                mSensor, SensorManager.SENSOR_DELAY_NORMAL);
        super.onResume();
    }

    protected void onPause() {
        super.onPause();
        // Call disable to ensure that the trigger request has been canceled.
    }

    @Override
    public void onSensorChanged(SensorEvent event) {

        float[] currValues = {event.values[0], event.values[1],event.values[2]};
        shakeOccured = false;
        for (int i = 0; i < 3; i++) {
            if (Math.abs(currValues[i] - mLastValues[i]) > 10) {
                Log.e("T", currValues[i] + " " + mLastValues[i]);
                        Log.e("a", "x: " +event.values[0] +
                " y: " + event.values[1] +
                " z: " + event.values[2]);
                mLastValues = currValues;
                shakeOccured = true;
            }
        }
        if (shakeOccured) {
            Log.e("SHAKE", "shake detected");
            Intent intent = new Intent(mContext, WatchToPhoneService.class);
            intent.putExtra("DATA", "SHAKE");
            startService(intent);
        }
        mLastValues = currValues;

//        Log.e("a", "x: " +event.values[0] +
//                " y: " + event.values[1] +
//                " z: " + event.values[2]);
//sensor set acceleration
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

}
