package com.example.fmirdita.finalpollitik;

import android.content.Intent;
import android.util.Log;

import com.google.android.gms.wearable.MessageEvent;
import com.google.android.gms.wearable.WearableListenerService;

import java.nio.charset.StandardCharsets;

/**
 * Created by fmirdita on 3/4/16.
 */
public class WatchListenerService extends WearableListenerService {

    final static String DATA ="DATA";

    @Override
    public void onMessageReceived(MessageEvent messageEvent) {

        if (messageEvent.getPath().equalsIgnoreCase("/" + DATA)) {

            String value = new String(messageEvent.getData(), StandardCharsets.UTF_8);
            Log.e("Listener", value);

            Log.e("RM", "message: " + value);


            Intent intent = new Intent(this, MainGrid.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.putExtra(DATA, value);
            startActivity(intent);
        } else {
            super.onMessageReceived(messageEvent);
        }
    }
}
