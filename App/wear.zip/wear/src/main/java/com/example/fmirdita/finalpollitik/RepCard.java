package com.example.fmirdita.finalpollitik;

import android.app.Fragment;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.wearable.view.CardFragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.zip.Inflater;

/**
 * Created by fmirdita on 3/4/16.
 */
public class RepCard extends Fragment {

    View mRootView;
    int mCardColor;
    String mTitle;
    String mName;
    String mParty;
    int mIcon;
    View.OnClickListener mOnClickListener;
    final Context mContext = RepCard.this.getActivity();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        mRootView = inflater.inflate(R.layout.rep_card_fragment, container, false);
        ((TextView)mRootView.findViewById(R.id.title)).setText(mTitle);
        ((TextView)mRootView.findViewById(R.id.name)).setText(mName);
        ((TextView)mRootView.findViewById(R.id.party)).setText(mParty);
        (mRootView.findViewById(R.id.card)).setBackgroundColor(mCardColor);
        ((ImageView)mRootView.findViewById(R.id.partyIcon)).setImageResource(mIcon);


        (mRootView.findViewById(R.id.card)).setOnClickListener(mOnClickListener);

        return mRootView;
    }

    public void setTitle(String title) {
        mTitle = title;
    }

    public void setName(String name) {
        mName = name;
    }

    public void setParty(String party) {

        if (party.equals("R")) {
            mIcon = R.drawable.elephant;
            mParty = "Republican";
            mCardColor = R.color.pollitik_red;
        } else {
            mIcon = R.drawable.donkey;
            mParty = "Democrat";
            mCardColor = R.color.pollitik_blue;
        }
    }

    public void setCardClickListener(final String data, final Context activityContext) {

        Context ctx = RepCard.this.getActivity();

        mOnClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(activityContext, WatchToPhoneService.class);
                intent.putExtra("DATA",data);
                Log.e("I", "Sending " + data + "to PhoneService");
                RepCard.this.getActivity().startService(intent);
            }
        };
    }

}
