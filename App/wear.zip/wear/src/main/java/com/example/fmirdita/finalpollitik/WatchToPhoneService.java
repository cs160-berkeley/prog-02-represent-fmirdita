package com.example.fmirdita.finalpollitik;

import android.app.Service;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;

import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.wearable.Node;
import com.google.android.gms.wearable.NodeApi;
import com.google.android.gms.wearable.Wearable;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by fmirdita on 3/4/16.
 */

public class WatchToPhoneService extends Service implements GoogleApiClient.ConnectionCallbacks {

    private GoogleApiClient mWatchApiClient;
    private List<Node> nodes = new ArrayList<>();
    private String repData;

    @Override
    public int onStartCommand (Intent intent, int flags, int startId){
        repData = intent.getStringExtra("DATA");
        return 0;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Log.e("s", "service created!");

        //initialize the googleAPIClient for message passing
        mWatchApiClient = new GoogleApiClient.Builder( this )
                .addApi( Wearable.API )
                .addConnectionCallbacks(this)
                .build();
        //and actually connect it
        mWatchApiClient.connect();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mWatchApiClient.disconnect();
    }


    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override //alternate method to connecting: no longer create this in a new thread, but as a callback
    public void onConnected(Bundle bundle) {
        final Service _this = this;
        Log.e("T", "in onconnected repData = " + repData);
        if (repData.equals("start")) {
            Wearable.NodeApi.getConnectedNodes(mWatchApiClient)
                    .setResultCallback(new ResultCallback<NodeApi.GetConnectedNodesResult>() {
                        @Override
                        public void onResult(NodeApi.GetConnectedNodesResult getConnectedNodesResult) {
                            nodes = getConnectedNodesResult.getNodes();
                            Log.e("T", "found nodes: " + nodes);
                            //when we find a connected node, we populate the list declared above
                            //finally, we can send a message
                            sendMessage("/START", "");
                            Log.e("sent", "start");
                        }
                    });

        } else if (repData.equals("SHAKE")) {
            Wearable.NodeApi.getConnectedNodes(mWatchApiClient)
                    .setResultCallback(new ResultCallback<NodeApi.GetConnectedNodesResult>() {
                        @Override
                        public void onResult(NodeApi.GetConnectedNodesResult getConnectedNodesResult) {
                            nodes = getConnectedNodesResult.getNodes();
                            Log.e("T", "found nodes: " + nodes);
                            //when we find a connected node, we populate the list declared above
                            //finally, we can send a message
                            sendMessage("/SHAKE", "randomize");
                            Log.e("sent", "SHAKE, going to randomize");
                        }
                    });
        } else {
                Wearable.NodeApi.getConnectedNodes(mWatchApiClient)
                        .setResultCallback(new ResultCallback<NodeApi.GetConnectedNodesResult>() {
                            @Override
                            public void onResult(NodeApi.GetConnectedNodesResult getConnectedNodesResult) {
                                nodes = getConnectedNodesResult.getNodes();
                                Log.e("T", "found nodes: " + nodes);
                                //when we find a connected node, we populate the list declared above
                                //finally, we can send a message
                                sendMessage("/DATA", repData);
                                Log.e("sent", repData);
                            }
                        });
        }
        _this.stopSelf();

    }

    @Override //we need this to implement GoogleApiClient.ConnectionsCallback
    public void onConnectionSuspended(int i) {}

    private void sendMessage(final String path, final String text ) {
        for (Node node : nodes) {
            Log.e("T", "sending to node: " + node);
            Wearable.MessageApi.sendMessage(
                    mWatchApiClient, node.getId(), path, text.getBytes());
        }
    }

}

