package com.example.fmirdita.finalpollitik;

import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Created by fmirdita on 3/11/16.
 */
public class VoteCard extends Fragment{

    View mRootView;
    String mVoteResults;
    String mDistrict;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        mRootView = inflater.inflate(R.layout.vote_card_fragment, container, false);
        ((TextView) mRootView.findViewById(R.id.vote_results)).setText(mVoteResults);
        ((TextView) mRootView.findViewById(R.id.district)).setText(mDistrict);

        return mRootView;
    }

    public void setVoteResults(String results) {
        mVoteResults = results;
    }

    public void setDistrict(String district) {
        mDistrict = district;
    }

}
